package model;

public interface Calcolo {
	
	
}
