package exceptions;


public class CalcolatriceException extends Exception {
	
   
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CalcolatriceException(String message) {
		super(message);
        
    }
    
}